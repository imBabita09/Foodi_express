import { Outlet } from "react-router-dom";
import LFooter from "./Layouts/LoginA/LFooter";
import LHeader from "./Layouts/LoginA/LHeader";

export default function Masterlogin(){
    return(
        <>
        <LHeader/>
        <Outlet/>
        <LFooter/>
        </>
    )
}