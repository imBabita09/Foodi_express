import { Outlet } from "react-router-dom";
import UFooter from "./Layouts/User/UFooter";
import UHeader from "./Layouts/User/UHeader";

export default function MasterUser(){
    return(
        <>
        <UHeader/>
        <Outlet/>
        <UFooter/>
        </>
    )
}