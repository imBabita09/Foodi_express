export default function Viewitems(){
    const product=[
        {
            Food_Categorie:"Indian",
            Food_name: "Rajma Chawal",
            Price:"100",
            Discount:"10%",
            Description:"It is a delicious and hearty meal that is perfect for lunch or dinner",
            Upload_item_image:"Rajma-Chawal.jpg"

        },
        {
            Food_Categorie:"South Indian",
            Food_name: "Dosa",
            Price:"130",
            Discount:"10%",
            Description:"Dosa is a traditional South Indian dish that is popular all over India and around the world.",
            Upload_item_image:"dosa.jpg"

        },
        {
            Food_Categorie:"Fast Food",
            Food_name: "Burgur",
            Price:"50",
            Discount:"30%",
            Description:"It is a delicious and hearty meal that is perfect for lunch or dinner",
            Upload_item_image:"Rajma-Chawal.jpg"

        },
        {
            Food_Categorie:"Punjabi style",
            Food_name: "Makki roti and Saag",
            Price:"200",
            Discount:"50%",
            Description:"It is a delicious and hearty meal that is perfect for lunch or dinner",
            Upload_item_image:"Rajma-Chawal.jpg"

        }
    ]
    return(
        <>
            <div className="container mt-5 p-5 table-responsive">
                <table className="table table-bordered table-striped table-hover">
                    <thead>
                        <tr>
                            <th>Sr.No</th>
                            <th>Food name</th>
                            <th>Price</th>
                            <th>Discount</th>
                            <th>Descriptionr</th>
                            <th>Upload item image</th>
                        </tr>
                    </thead>
                    {product.map((el,index)=>(
                        <tr key={index}>
                            <td>{index+1}</td>
                            <td>{el.Food_name}</td>
                            <td>{el.Price}</td>
                            <td>{el.Discount}</td>
                            <td>{el.Description}</td>
                            <td><img src={"assets/img/"+`${el.Upload_item_image}`} style={{height:"100px",width:"100px"}}></img></td>
                        </tr>
                    ))}
                </table>
            </div>
        
        </>
    )
}