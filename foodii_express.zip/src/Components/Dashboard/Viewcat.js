export default function Viewcat(){
    const product=[
        {
            Food_Categorie:"Indian",
            Food_name: "Rajma Chawal",
            Description:"It is a delicious and hearty meal that is perfect for lunch or dinner",
            Upload_item_image:"Rajma-Chawal.jpg"

        },
        {
            Food_Categorie:"South Indian",
            Food_name: "Dosa",
            Description:"Dosa is a traditional South Indian dish that is popular all over India and around the world.",
            Upload_item_image:"Rajma-Chawal.jpg"

        },
        {
            Food_Categorie:"Fast Food",
            Food_name: "Burgur",
            Description:"It is a delicious and hearty meal that is perfect for lunch or dinner",
            Upload_item_image:"Rajma-Chawal.jpg"

        },
        {
            Food_Categorie:"Punjabi style",
            Food_name: "Makki roti and Saag",
            Description:"It is a delicious and hearty meal that is perfect for lunch or dinner",
            Upload_item_image:"Rajma-Chawal.jpg"

        }
    ]
    return(
        <>
    
            <div className="container mt-5 p-5 table-responsive">
                <table className="table table-bordered table-striped table-hover">
                    <thead>
                        <tr>
                            <th>Sr.No</th>
                            <th>Food Categorie</th>
                            <th>Food name</th>
                            <th>Description</th>
                            <th>Upload item image</th>
                            
                        </tr>
                    </thead>
                    {product.map((el,index)=>(
                        <tr key={index}>
                            <td>{index+1}</td>
                            <td>{el.Food_Categorie}</td>
                            <td>{el.Food_name}</td>
                            <td>{el.Description}</td>
                            <td><img src={"assets/img/"+`${el.Upload_item_image}`} style={{height:"100px",width:"100px"}}></img></td>
                        </tr>
                    ))}
                </table>
            </div>
        
        </>
    )
}