import React from 'react';
export default function Dashboard(){

    return(
        <>
<br/>
            <div className="container">
              <div className="row">
                <div className="colmd-4">
                  <h3>Welcome, Admin</h3>
                </div>
              </div>
            </div>

            {/* <!-- Navbar --> */}
            <div className="container mb-5 p-5">
              <div className="row mb-5 pb-5">
                <div className="col-md-4 p-3">
                  <div className="card text-bg-dark mb-3" style={{ maxWidth: '18rem;' }}>
                    <div className="card-header">200+</div>
                    <div className="card-body py-5">
                      <h5 className="card-title"><i class="fa fa-coffee fa-2x " ></i>Categories</h5>
                      <a href="/cat" className="card-link">Add Categories</a>
                      <a href="/viewcat" className="card-link">View Categories</a>
                    </div>
                  </div>
                </div>

                <div className="col-md-4 p-3">
                  <div className="card text-bg-dark  mb-3" style={{ maxWidth: '18rem;' }}>
                    <div className="card-header">200+</div>
                    <div className="card-body py-5">
                      <h5 className="card-title"><i className="fas fa-shopping-cart fa-2x"></i>ORDER</h5>
                      <a href="/order" className="card-link">View order</a>
                      <a href="/addorder" className="card-link">Add order</a>
                    </div>
                  </div>
                </div>
                
                <div className="col-md-4 p-3">
                  <div className="card text-bg-dark mb-3" style={{ maxWidth: '18rem;' }}>
                    <div className="card-header">10+</div>
                    <div className="card-body py-5">
                      <h5 className="card-title"> <i class="fa fa-user fa-2x"></i>MENU</h5>
                      <a href="/additems" className="card-link">Add Items</a>
                      <a href="viewitems" className="card-link">View Items</a>
                    </div>
                  </div>
                </div>
              </div>

            </div>
        </>

    )
} 