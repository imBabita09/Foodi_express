export default function Vieworder(){
    const product=[
        {
            Customer_name:"Anu",
            Order_date_and_time:"09/03/2023",
            Order_items:"Dosa,Regular Pizza, 40ml Coke",
            Order_status:"True",
            Payment_method:"Cash on Delivery"
        },
        {
            Customer_name:"Anu",
            Order_date_and_time:"09/03/2023",
            Order_items:"Dosa,One Pizza, 40ml Coke",
            Order_status:"True",
            Payment_method:"Cash on Delivery"
        },
        {
            Customer_name:"Anu",
            Order_date_and_time:"09/03/2023",
            Order_items:"Dosa, Regular Pizza, 40ml Coke",
            Order_status:"True",
            Payment_method:"Cash on Delivery"
        },
        {
            Customer_name:"Anu",
            Order_date_and_time:"09/03/2023",
            Order_items:"Dosa,Regular Pizza, 40ml Coke",
            Order_status:"True",
            Payment_method:"Cash on Delivery"
        }
    ]
    return(
        <>
    
            <div className="container mt-5 p-5 table-responsive">
                <table className="table table-bordered table-striped table-hover">
                    <thead>
                        <tr>
                            <th>Sr.No</th>
                            <th>Customer name</th>
                            <th>Order date and time</th>
                            <th>Order items</th>
                            <th>Order status</th>
                            <th>Payment method</th>
                            
                        </tr>
                    </thead>
                    {product.map((el,index)=>(
                        <tr key={index}>
                            <td>{index+1}</td>
                            <td>{el.Customer_name}</td>
                            <td>{el.Order_date_and_time}</td>
                            <td>{el.Order_items}</td>
                            <td>{el.Order_status}</td>
                            <td>{el.Payment_method}</td>
                        </tr>
                    ))}
                </table>
            </div>
        
        </>
    )
}