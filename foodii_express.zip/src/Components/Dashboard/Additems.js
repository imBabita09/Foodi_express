export default function Additems(){
    return(
        <>
<br/>
    <section className="vh-90" style={{backgroundColor: '#2779e2;'}}>
  <div className="container h-90">
    <div className="row d-flex justify-content-center align-items-center h-90">
      <div className="col-xl-9">

        <h1 className="text-dark mb-4">Add Items</h1>

        <div className="card" style={{borderRadius: '15px;'}}>
          <div className="card-body">

            <div className="row align-items-center py-3">
              <div className="col-md-3 ps-5">

                <h6 className="mb-0">Food name</h6>

              </div>
              <div className="col-md-9 pe-5">

                <input type="text" className="form-control form-control-lg" placeholder="Enter food name" />

              </div>
            </div>
            <div className="row align-items-center py-3">
              <div className="col-md-3 ps-5">

                <h6 className="mb-0">Price</h6>

              </div>
              <div className="col-md-9 pe-5">

                <input type="text" className="form-control form-control-lg" placeholder="Enter food price" />

              </div>
            </div>

            <hr className="mx-n3"/>
            <div className="row align-items-center py-3">
              <div className="col-md-3 ps-5">

                <h6 className="mb-0">Discount</h6>

              </div>
              <div className="col-md-9 pe-5">

                <input type="text" className="form-control form-control-lg" placeholder="Enter food discount" />

              </div>
            </div>
            <div className="row align-items-center py-3">
              <div className="col-md-3 ps-5">

                <h6 className="mb-0">Description</h6>

              </div>
              <div className="col-md-9 pe-5">

                <textarea className="form-control" rows="3" placeholder="Enter description"></textarea>

              </div>
            </div>

            <hr className="mx-n3"/>

            <div className="row align-items-center py-3">
              <div className="col-md-3 ps-5">

                <h6 className="mb-0">Upload item image</h6>

              </div>
              <div className="col-md-9 pe-5">

                <input className="form-control form-control-lg" id="formFileLg" type="file" />
                <div className="small text-muted mt-2">Upload your </div>

              </div>
            </div>

            <hr className="mx-n3"/>

            <div className="px-5 py-4">
              <button type="submit" className="btn btn-primary btn-lg">Submit</button>
            </div>

          </div>
        </div>

      </div>
    </div>
  </div>
</section>
        

        </>
    )
    
        
}