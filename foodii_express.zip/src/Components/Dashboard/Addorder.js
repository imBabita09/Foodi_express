export default function Addorder(){

    return(
        <>
       
    <br/>
    <section className="vh-90" style={{backgroundColor: '#2779e2;'}}>
  <div className="container h-90">
    <div className="row d-flex justify-content-center align-items-center h-90">
      <div className="col-xl-9">

        <h1 className="text-dark mb-4">Add Order</h1>

        <div className="card" style={{borderRadius: '15px;'}}>
          <div className="card-body">

            <div className="row align-items-center pt-4 pb-3">
                 <div className="col-md-3 ps-5">

                    <h5 className="mb-0">Customer name</h5>

                </div>
                <div className="col-md-9 pe-5">

                    <input type="text" className="form-control form-control-lg" placeholder="Enter name" />

                </div>
            </div>

            <hr className="mx-n3"/>

            <div className="row align-items-center py-3">
              <div className="col-md-3 ps-5">

                <h6 className="mb-0">Order date</h6>

              </div>
              <div className="col-md-9 pe-5">

                <input type="text" className="form-control form-control-lg" placeholder="DD/MM/YYYY" />

              </div>
            </div>
            <div className="row align-items-center py-3">
              <div className="col-md-3 ps-5">

                <h6 className="mb-0">Order item</h6>

              </div>
              <div className="col-md-9 pe-5">

                <input type="text" className="form-control form-control-lg" placeholder="Enter item" />

              </div>
            </div>

            <hr className="mx-n3"/>
            <div className="row align-items-center py-3">
              <div className="col-md-3 ps-5">

                <h6 className="mb-0">Order status</h6>

              </div>
              <div className="col-md-9 pe-5">

              <select class="form-select form-select-lg mb-3" aria-label=".form-select-lg example">
                    <option selected>Choose Order Status</option>
                    <option value="1">True</option>
                    <option value="2">False</option>
                </select>

              </div>
            </div>
            <div className="row align-items-center py-3">
              <div className="col-md-3 ps-5">

                <h6 className="mb-0">Payment method</h6>

              </div>
              <div className="col-md-9 pe-5">

                <div class="form-check form-check-inline">
                    <input className="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1"/>
                    <label className="form-check-label" for="inlineRadio1">Cash on Delivery</label>
                </div>
                <div class="form-check form-check-inline">
                    <input className="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2"/>
                    <label className="form-check-label" for="inlineRadio2">UPI</label>
                </div>
                <div class="form-check form-check-inline">
                    <input className="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2"/>
                    <label className="form-check-label" for="inlineRadio2">Card</label>
                </div>

              </div>
            </div>

            <hr className="mx-n3"/>

            <div className="px-5 py-4">
              <button type="submit" className="btn btn-primary btn-lg">Submit</button>
            </div>

          </div>
        </div>

      </div>
    </div>
  </div>
</section>


        </>
    )
}