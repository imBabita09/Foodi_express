export default function Indian(){

    return(
        <>
            <div className="row row-cols-1 row-cols-md-3 g-4 px-3 py-5">
                <div className="col ">
                    <div className="card">
                        <img src="/assets/img/u-2.jpg" className="card-img-top" alt="..." style={{width: '100%', height: '100%'}}/>
                        <div className="card-body">
                            <h5 className="card-title">Veg. Thali</h5>
                            <p className="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                            <p className="card-text"><small className="text-body-secondary">Last updated 3 mins ago</small></p>
                            <div className="d-grid gap-2 col-8 mx-auto">
                                <a href="/user" ><button type="button" className="btn btn-primary btn-lg " 
                                style={{ paddingLeft: '2.5rem;', paddingRight: '2.5rem;' }}>Add to card</button></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="col ">
                    <div className="card">
                        <img src="/assets/img/u-1.jpg" className="card-img-top" alt="..." style={{width: '100%', height: '97%'}}/>
                        <div className="card-body">
                            <h5 className="card-title">Channa Rice </h5>
                            <p className="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                            <p className="card-text"><small className="text-body-secondary">Last updated 3 mins ago</small></p>
                            <div className="d-grid gap-2 col-8 mx-auto">
                                <a href="/user" ><button type="button" className="btn btn-primary btn-lg " 
                                style={{ paddingLeft: '2.5rem;', paddingRight: '2.5rem;' }}>Add to card</button></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="col ">
                    <div className="card">
                        <img src="/assets/img/u-3.jpg" className="card-img-top" alt="..."style={{width: '100%', height: '100%'}} />
                        <div className="card-body">
                            <h5 className="card-title">Shahi Panner</h5>
                            <p className="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                            <p className="card-text"><small className="text-body-secondary">Last updated 3 mins ago</small></p>
                            <div className="d-grid gap-2 col-8 mx-auto">
                                <a href="/user" ><button type="button" className="btn btn-primary btn-lg " 
                                style={{ paddingLeft: '2.5rem;', paddingRight: '2.5rem;' }}>Add to card</button></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}