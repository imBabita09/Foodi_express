export default function HeaderA(){
return(
    <>
    <nav className="navbar bg-dark navbar navbar-expand-lg bg-body-tertiary p-3" data-bs-theme="dark">
  <div className="container-fluid">
  <a href="/" className="navbar-brand p-0">
                    <h1 className="text-primary m-0"><i className="fa fa-utensils me-3"></i>Foodi Express</h1>
                    
                </a>
    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span className="navbar-toggler-icon"></span>
    </button>



  <div className="col-6">

  
    <div className="collapse navbar-collapse" id="navbarSupportedContent">
      
      <ul className="navbar-nav me-auto mb-2 mb-lg-0  mx-5">
        <li className="nav-item">
          <a className="nav-link active" aria-current="page" href="/admin">Dashboard</a>
        </li>
        <li class="nav-item dropdown mx-3"><a className="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">Categories</a>
        <ul className="dropdown-menu">
            <li><a className="dropdown-item" href="/cat">Add Categories</a></li>
            <li><a className="dropdown-item" href="/viewcat">View Categories</a></li>
          </ul>
        </li>
        <li class="nav-item dropdown mx-3"><a className="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">Order</a>
        <ul className="dropdown-menu">
            <li><a className="dropdown-item" href="/addorder">Add Order</a></li>
            <li><a className="dropdown-item" href="/order">View Order</a></li>
          </ul>
        </li>
        <li class="nav-item dropdown mx-3"><a className="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">Menu</a>
        <ul className="dropdown-menu">
            <li><a className="dropdown-item" href="/additems">Add Items</a></li>
            <li><a className="dropdown-item" href="/viewitems">View Items</a></li>
          </ul>
        </li>
        
        <li className="nav-item dropdown mx-4 ">
          <a className="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
          <i class="fa fa-user fa-1x"></i>
          </a>
          <ul className="dropdown-menu">
            <li><a className="dropdown-item" href="#">Admin</a></li>
            <li><a className="dropdown-item" href="#"></a></li>
            <li><a className="dropdown-item" href="/login">LogOut</a></li>
          </ul>
        </li>
    
      </ul>
     
      </div>
    </div>
  </div>
</nav>
    </>
)
    }