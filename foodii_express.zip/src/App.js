import logo from './logo.svg';
import './App.css';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
// import 'bootstrap/dist/css/bootstrap.min.css';
import Menu from './Components/Menu';
import Home from './Components/Home';
import About from './Components/About';
import Reservation from './Components/Reservation';
import Team from './Components/Team';
import Login from './Authentication/Login';
import Dashboard from './Components/Dashboard/Dashboard';
import Master from './Master';
import MasterAdmin from './MasterAdmin';
import Masterlogin from './Masterlogin';
import Addcat from './Components/Dashboard/Addcat';
import Viewcat from './Components/Dashboard/Viewcat';
import Addorder from './Components/Dashboard/Addorder';
import Register from './Authentication/Register';
import Additems from './Components/Dashboard/Additems';
import Viewitems from './Components/Dashboard/Viewitems';
import Vieworder from './Components/Dashboard/Vieworder';
import UserLogin from './Authentication/UserLogin';
import Userpage from './Components/User/Components/Userpage';
import MasterUser from './MasterUser';
import Indian from './Components/User/Components/Indian';
import Southindian from './Components/User/Components/Southindian';
function App() {
  return (
    <Router>
    <Routes>
    <Route path="/" element={<Master/>}>
        <Route path="/" element={<Home/>}/>
        <Route path="/about" element={<About/>}/>
        <Route path="/menu" element={<Menu/>}/>
        <Route path="/re" element={<Reservation/>}/>
        <Route path="/team" element={<Team/>}/>

    </Route>
    <Route path="/" element={<Masterlogin/>}>
    <Route path="/login" element={<Login/>}/>
    <Route path="/register" element={<Register/>}/>
    <Route path="/userlogin" element={<UserLogin/>}/>
    </Route>

    <Route path="/" element={<MasterAdmin/>}>
    <Route path="/admin" element={<Dashboard/>}/>
    <Route path="/additems" element={<Additems/>}/>
    <Route path="/viewitems" element={<Viewitems/>}/>
    <Route path="/order" element={<Vieworder/>}/>
    <Route path="/Cat" element={<Addcat/>}/>
    <Route path="/viewcat" element={<Viewcat/>}/>
    <Route path="/addorder" element={<Addorder/>}/>
    
    </Route>

    <Route path="/" element={<MasterUser/>}>
    <Route path="/user" element={<Userpage/>}/>
    <Route path="/indian" element={<Indian/>}/>
    <Route path="/south" element={<Southindian/>}/>
    </Route>

    </Routes>
  </Router>
  );
}

export default App;
