import { Outlet } from "react-router-dom";
import FooterA from "./Layouts/admin/FooterA";
import HeaderA from "./Layouts/admin/HeaderA";


export default function MasterAdmin(){
    return(
        <>
        <HeaderA/>
        <Outlet/>
        <FooterA/>
        </>
    )
}